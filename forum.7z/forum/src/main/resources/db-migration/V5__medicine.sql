INSERT INTO medicine(medicine_pk, dealer_pk, details_medicine, effect, enable_medicine, name_medicine, price, where_production)
VALUES ('1','1','Thành phần:abc,xyz','Hỗ trợ điều trị trong thời gian bị mắc covid, thuốc kháng virus ngăn chặn sự nhân lên của virus',true,'Molnupiravir', '200000', 'Mỹ');
