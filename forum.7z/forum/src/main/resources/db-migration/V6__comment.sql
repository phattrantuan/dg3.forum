INSERT INTO comment(content_comment, enable_comment, thread_pk, user_pk)
VALUES ( 'Bài viết quá tuyệt vời', true, '1', '1');