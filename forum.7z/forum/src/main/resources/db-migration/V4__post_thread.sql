INSERT INTO post_thread(approved, content_of_thread, enable_post_thread, post_topic_pk, time_post_thread, title_thread, user_pk)
VALUES (false, 'Đăng tải thông tin về F1', true,'1' , '2022-04-21', 'Bảo vệ sức khỏe mùa covid-19', '1'),
       (true, 'Đăng tải thông tin về F0', true,'5' , '2022-04-21', 'F0 chống chọi lại covid- 19 như thế nào?', '1');