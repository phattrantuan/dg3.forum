INSERT INTO post_topic (name_topic,enable_post_topic)
VALUES ('Sức khỏe', true),
       ('Đời sống',true),
       ('Xã hội',true),
       ('Thực phẩm',true),
       ('Thuốc',true);