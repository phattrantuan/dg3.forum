INSERT INTO likes(comment_pk, user_pk, thread_pk, enable_like)
VALUES ('1','1','1',true);
